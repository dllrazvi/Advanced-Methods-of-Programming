from exceptions import VertexError, EdgeError
import copy
from random import randrange

def read_file(file_path): #reads a graph from a file
    file = open(file_path, "r")
    n, m = map(int, file.readline().split())
    g = Graph(n)
    for _ in range(m):
        v1, v2, cost = map(int, file.readline().split())
        g.add_edge(v1, v2, cost)
    file.close()
    return g #returns the graph


def write_file(file_path, g): #writes a graph to a file
    file = open(file_path, "w")
    file.write("{0} {1}\n".format(g.count_vertices(), g.count_edges()))
    for node in g.vertices_iterator():
        for neighbour in g.neighbours_iterator(node):
            file.write("{0} {1} {2}\n".format(node, neighbour, g.get_edge_cost(node, neighbour)))
    file.close() #closes the file


def random_graph(vertices_no, edges_no): #generates a random graph
    if edges_no > vertices_no * vertices_no:
        raise EdgeError("Too many edges!")
    g = Graph() #creates a graph
    for i in range(vertices_no): #adds vertices to the graph
        g.add_vertex(i) #adds a vertex to the graph
    for j in range(edges_no):
        v1 = randrange(vertices_no)
        v2 = randrange(vertices_no)
        while g.is_edge(v1, v2):
            v1 = randrange(vertices_no)
            v2 = randrange(vertices_no)
        g.add_edge(v1, v2, randrange(100000))
    return g #returns the graph


class Graph: #defines a graph
    def __init__(self, n=0, m=0): #initializes a graph
        self._vertices = set() #creates a set of vertices
        self._neighbours = {}
        self._transpose = {}
        self._cost = {}
        """
        for i in range(n): #adds vertices to the graph
            self.add_vertex(i)
        for j in range(m): #adds edges to the graph
            v1 = randrange(n)
            v2 = randrange(n)
            while self.is_edge(v1, v2): #checks if the edge already exists
                v1 = randrange(n)
                v2 = randrange(n)
            self.add_edge(v1, v2, randrange(1000000)) #adds an edge to the graph """

    def vertices_iterator(self): #returns an iterator to the set of vertices
        for vertex in self._vertices:
            yield vertex

    def neighbours_iterator(self, vertex): #returns an iterator to the set of (outbound) neighbours of a vertex
        if not self.is_vertex(vertex):
            raise VertexError("\nInvalid vertex.")
        for neighbour in self._neighbours[vertex]:
            yield neighbour #returns the neighbour

    def transpose_iterator(self, vertex): #returns an iterator to the set of inbound neighbours of a vertex
        if not self.is_vertex(vertex):
            raise VertexError("\nInvalid vertex.") #raises an exception if the vertex is invalid
        for neighbour in self._transpose[vertex]:
            yield neighbour #returns the neighbour

    def edges_iterator(self): #returns an iterator to the set of edges
        for key, value in self._cost.items(): #iterates through the edges
            yield key[0], key[1], value #returns the edge

    def is_vertex(self, vertex): #checks if a vertex belongs to the graph
        return vertex in self._vertices #returns True if the vertex belongs to the graph

    def is_edge(self, vertex1, vertex2): #checks if an edge belongs to the graph
        return vertex1 in self._neighbours and vertex2 in self._neighbours[vertex1] #returns True if the edge belongs to the graph

    def count_vertices(self): #returns the number of vertices in the graph
        return len(self._vertices) #returns the number of vertices

    def count_edges(self): #returns the number of edges in the graph
        return len(self._cost)

    def in_degree(self, vertex): #returns the number of edges with the end point vertex
        if vertex not in self._transpose:
            raise VertexError("\nThe specified vertex does not exist.") #raises an exception if the vertex is invalid
        return len(self._transpose[vertex])

    def out_degree(self, vertex): #returns the number of edges with the start point vertex
        if vertex not in self._neighbours:
            raise VertexError("\nThe specified vertex does not exist.")
        return len(self._neighbours[vertex]) #returns the number of edges

    def get_edge_cost(self, vertex1, vertex2): #returns the cost of an edge
        if (vertex1, vertex2) not in self._cost:
            raise EdgeError("\nThe specified edge does not exist.")
        return self._cost[(vertex1, vertex2)]

    def set_edge_cost(self, vertex1, vertex2, new_cost): #sets the cost of an edge
        if (vertex1, vertex2) not in self._cost:
            raise EdgeError("\nThe specified edge does not exist.") #raises an exception if the edge is invalid
        self._cost[(vertex1, vertex2)] = new_cost #sets the cost of the edge

    def add_vertex(self, vertex): #adds a vertex to the graph
        if self.is_vertex(vertex):
            raise VertexError("\nCannot add a vertex which already exists.")
        self._vertices.add(vertex) #adds the vertex to the set of vertices
        self._neighbours[vertex] = set() #adds the vertex to the set of neighbours
        self._transpose[vertex] = set()     #adds the vertex to the set of inbound neighbours

    def add_edge(self, vertex1, vertex2, edge_cost=0): #adds an edge to the graph
        if self.is_edge(vertex1, vertex2): #checks if the edge already exists
            raise EdgeError("\nThe specified edge already exists")
        if not self.is_vertex(vertex1) or not self.is_vertex(vertex2): #checks if the vertices exist
            raise EdgeError("\nThe vertices on the edge do not exist.")
        self._neighbours[vertex1].add(vertex2)
        self._transpose[vertex2].add(vertex1)
        self._cost[(vertex1, vertex2)] = edge_cost #adds the edge to the set of edges

    def remove_edge(self, vertex1, vertex2): #removes an edge from the graph
        if not self.is_edge(vertex1, vertex2): #checks if the edge exists
            raise EdgeError("\nThe specified edge does not exist.")
        del self._cost[(vertex1, vertex2)]
        self._neighbours[vertex1].remove(vertex2)
        self._transpose[vertex2].remove(vertex1)

    def remove_vertex(self, vertex): #removes a vertex from the graph
        if not self.is_vertex(vertex):
            raise VertexError("\nCannot remove a vertex which doesn't exist.")
        to_remove = []
        for node in self._neighbours[vertex]: #removes the edges with the vertex as start point
            to_remove.append(node)
        for node in to_remove: #removes the edges with the vertex as end point
            self.remove_edge(vertex, node)
        to_remove = []
        for node in self._transpose[vertex]: #removes the edges with the vertex as end point
            to_remove.append(node)
        for node in to_remove:
            self.remove_edge(node, vertex)
        del self._neighbours[vertex]
        del self._transpose[vertex]
        self._vertices.remove(vertex)

    def copy(self): #returns a copy of the graph
        return copy.deepcopy(self), copy.deepcopy(self._cost) #returns a copy of the graph